CTF KEY: ... something clever ...
WORD: village
  
  
